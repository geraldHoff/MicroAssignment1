public class RoomDimension {
    int height;
    int width;

    //sets the height and width.
    RoomDimension(int height, int width){
        this.height = height;
        this.width = width;
    }

    //gets the area of the room.
    public int getArea(){
        return height * width;
    }
}

class RoomCarpet {

    RoomDimension room;
    int costPerFoot;

    //stores dimensions and creates RoomDimension object.
    RoomCarpet(int height, int width, int costPerFoot){
        this.costPerFoot = costPerFoot;
        room = new RoomDimension(height, width);
    }

    //returns the cost of the room
    public int getCost(){
        return room.getArea() * costPerFoot;
    }
}