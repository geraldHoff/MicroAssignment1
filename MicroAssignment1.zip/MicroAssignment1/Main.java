import java.util.Scanner;

/**
 * Name: Gerald Hoff
 * CptS 233: MicroAssignment #1
 * Date: 9/4/2020
 * git repo: https://github.com/geraldHoff/MicroAssignment1.git
 */

public class Main {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);

        System.out.println("Enter the width:");
        int width = console.nextInt();

        System.out.println("Enter the height:");
        int height = console.nextInt();

        System.out.println("Enter the cost per foot:");
        int costPerFoot = console.nextInt();

        //creates objects that calculate the cost of the carpeting.
        RoomCarpet roomCarpet = new RoomCarpet(height, width, costPerFoot);

        //prints the cost
        System.out.println("The carpet will cost $" + roomCarpet.getCost() + ".");
    }
}
